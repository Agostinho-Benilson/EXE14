package com.example.exe14_tic;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;

import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends AppCompatActivity {
    private int delay; //tempo de espera
    private int interval; // o intervalo da realização da tarefa.
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Timer timer = new Timer();
        delay = 3000;
       /* timer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
            }
        } , delay, interval);*/

        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                Intent intent = new Intent(getApplicationContext(), MainActivity2.class);
                startActivity(intent);
            }
        },delay);
    }
}